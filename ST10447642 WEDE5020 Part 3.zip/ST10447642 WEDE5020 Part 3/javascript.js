
// ===== GLOBAL VARIABLES AND CONSTANTS =====
const CONFIG = {
    toastDuration: 5000, // 5 seconds
    animationDuration: 300, // 300ms
    searchDebounce: 300 // 300ms debounce for search
};

// ===== DOM CONTENT LOADED EVENT =====
/**
 * Initializes all functionality when the DOM is fully loaded
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log('NYT Vehicle Dealers - Initializing Enhanced Functionality...');
    
    try {
        // Initialize all functionality modules
        initializeNavigation();
        initializeForms();
        initializeVehicleFilters();
        initializeFinanceCalculator();
        initializeImageGallery();
        initializeInteractiveElements();
        initializeSearchFunctionality();
        initializeAccordions();
        initializeDynamicContent();
        
        // Set current year in footer for copyright
        initializeCurrentYear();
        
        // Initialize vehicle count on products page
        initializeVehicleCount();
        
        console.log('NYT Vehicle Dealers - All modules initialized successfully!');
    } catch (error) {
        console.error('Error during initialization:', error);
        showToast('There was an error loading the page functionality. Please refresh the page.', 'error');
    }
});

// ===== NAVIGATION FUNCTIONALITY =====
/**
 * Handles navigation menu functionality including active state management
 */
function initializeNavigation() {
    console.log('Initializing navigation functionality...');
    
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-menu a');
    
    // Set active state for current page
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        if (linkHref === currentPage || (currentPage === '' && linkHref === 'index.html')) {
            link.classList.add('active');
            link.setAttribute('aria-current', 'page');
        }
        
        // Add keyboard navigation support
        link.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    });
    
    console.log('Navigation initialized successfully');
}

// ===== SEARCH FUNCTIONALITY =====
/**
 * Initializes search functionality across the site
 */
function initializeSearchFunctionality() {
    console.log('Initializing search functionality...');
    
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    
    if (searchInput && searchButton) {
        // Button click search
        searchButton.addEventListener('click', performSearch);
        
        // Enter key search
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
        
        // Real-time search with debouncing
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                if (this.value.length >= 3 || this.value.length === 0) {
                    performSearch();
                }
            }, CONFIG.searchDebounce);
        });
        
        console.log('Search functionality initialized');
    }
    
    // Clear search functionality
    const clearSearchBtn = document.getElementById('clear-search');
    if (clearSearchBtn) {
        clearSearchBtn.addEventListener('click', clearSearch);
    }
}

/**
 * Performs search based on current input
 */
function performSearch() {
    const searchInput = document.getElementById('search-input');
    const searchTerm = searchInput.value.trim().toLowerCase();
    
    console.log(`Performing search for: "${searchTerm}"`);
    
    // If on products page, filter vehicles
    if (window.location.pathname.includes('Products.html') || document.querySelector('.products-grid')) {
        filterVehiclesBySearch(searchTerm);
    } else {
        // If not on products page but search exists, show message
        if (searchTerm) {
            showToast(`Searching for "${searchTerm}" - redirecting to vehicles page...`, 'success');
            // Redirect to products page with search parameter
            setTimeout(() => {
                window.location.href = `Products.html?search=${encodeURIComponent(searchTerm)}`;
            }, 1000);
        }
    }
}

/**
 * Filters vehicles based on search term
 * @param {string} searchTerm - The term to search for
 */
function filterVehiclesBySearch(searchTerm) {
    const vehicleCards = document.querySelectorAll('.vehicle-card');
    const noResultsMessage = document.getElementById('no-results');
    let visibleCount = 0;
    
    vehicleCards.forEach(card => {
        const vehicleName = card.querySelector('h3').textContent.toLowerCase();
        const vehicleDetails = card.querySelector('.vehicle-details').textContent.toLowerCase();
        const vehiclePrice = card.querySelector('.price').textContent.toLowerCase();
        
        const matchesSearch = !searchTerm || 
                            vehicleName.includes(searchTerm) || 
                            vehicleDetails.includes(searchTerm) ||
                            vehiclePrice.includes(searchTerm);
        
        if (matchesSearch) {
            showVehicleCard(card);
            visibleCount++;
            
            // Add search highlight if there's a search term
            if (searchTerm) {
                card.classList.add('search-highlight');
                // Remove highlight after animation
                setTimeout(() => {
                    card.classList.remove('search-highlight');
                }, 2000);
            } else {
                card.classList.remove('search-highlight');
            }
        } else {
            hideVehicleCard(card);
            card.classList.remove('search-highlight');
        }
    });
    
    // Show/hide no results message
    if (noResultsMessage) {
        if (visibleCount === 0 && searchTerm) {
            noResultsMessage.style.display = 'block';
        } else {
            noResultsMessage.style.display = 'none';
        }
    }
    
    // Update vehicle count display
    updateVehicleCount(visibleCount, vehicleCards.length);
    
    if (searchTerm) {
        showToast(`Found ${visibleCount} vehicles matching "${searchTerm}"`, 'success');
    }
}

/**
 * Clears search and shows all vehicles
 */
function clearSearch() {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        searchInput.value = '';
    }
    
    const noResultsMessage = document.getElementById('no-results');
    if (noResultsMessage) {
        noResultsMessage.style.display = 'none';
    }
    
    performSearch(); // This will show all vehicles since search term is empty
    showToast('Search cleared', 'success');
}

// ===== VEHICLE FILTERING FUNCTIONALITY =====
/**
 * Initializes vehicle filtering functionality
 */
function initializeVehicleFilters() {
    console.log('Initializing vehicle filters...');
    
    const categoryFilter = document.getElementById('category-filter');
    const priceFilter = document.getElementById('price-filter');
    const locationFilter = document.getElementById('location-filter');
    const resetFilters = document.getElementById('reset-filters');
    
    // Check URL parameters for search
    const urlParams = new URLSearchParams(window.location.search);
    const searchParam = urlParams.get('search');
    if (searchParam && document.getElementById('search-input')) {
        document.getElementById('search-input').value = searchParam;
        filterVehiclesBySearch(searchParam);
    }
    
    // Add event listeners to filters
    if (categoryFilter) {
        categoryFilter.addEventListener('change', function() {
            filterVehicles();
            console.log('Category filter changed:', this.value);
        });
    }
    
    if (priceFilter) {
        priceFilter.addEventListener('change', function() {
            filterVehicles();
            console.log('Price filter changed:', this.value);
        });
    }
    
    if (locationFilter) {
        locationFilter.addEventListener('change', function() {
            filterVehicles();
            console.log('Location filter changed:', this.value);
        });
    }
    
    if (resetFilters) {
        resetFilters.addEventListener('click', resetAllFilters);
    }
    
    console.log('Vehicle filters initialized');
}

/**
 * Filters vehicles based on current filter selections
 */
function filterVehicles() {
    console.log('Filtering vehicles...');
    
    const categoryValue = document.getElementById('category-filter')?.value || 'all';
    const priceValue = document.getElementById('price-filter')?.value || 'all';
    const locationValue = document.getElementById('location-filter')?.value || 'all';
    const searchTerm = document.getElementById('search-input')?.value.trim().toLowerCase() || '';
    
    const vehicleCards = document.querySelectorAll('.vehicle-card');
    const noResultsMessage = document.getElementById('no-results');
    let visibleCount = 0;
    
    vehicleCards.forEach(card => {
        const category = card.getAttribute('data-category');
        const price = parseInt(card.getAttribute('data-price'));
        const location = card.getAttribute('data-location');
        
        // Check filter matches
        const categoryMatch = categoryValue === 'all' || category === categoryValue;
        const priceMatch = priceValue === 'all' || checkPriceRange(price, priceValue);
        const locationMatch = locationValue === 'all' || location === locationValue;
        
        // Check search match
        const vehicleName = card.querySelector('h3').textContent.toLowerCase();
        const vehicleDetails = card.querySelector('.vehicle-details').textContent.toLowerCase();
        const searchMatch = !searchTerm || 
                           vehicleName.includes(searchTerm) || 
                           vehicleDetails.includes(searchTerm);
        
        if (categoryMatch && priceMatch && locationMatch && searchMatch) {
            showVehicleCard(card);
            visibleCount++;
        } else {
            hideVehicleCard(card);
        }
    });
    
    // Show/hide no results message
    if (noResultsMessage) {
        if (visibleCount === 0) {
            noResultsMessage.style.display = 'block';
        } else {
            noResultsMessage.style.display = 'none';
        }
    }
    
    updateVehicleCount(visibleCount, vehicleCards.length);
    console.log(`Filtered: ${visibleCount} vehicles visible`);
}

/**
 * Shows a vehicle card with animation
 * @param {HTMLElement} card - The vehicle card element
 */
function showVehicleCard(card) {
    card.style.display = 'block';
    setTimeout(() => {
        card.style.opacity = '1';
        card.style.transform = 'scale(1)';
    }, 50);
}

/**
 * Hides a vehicle card with animation
 * @param {HTMLElement} card - The vehicle card element
 */
function hideVehicleCard(card) {
    card.style.opacity = '0';
    card.style.transform = 'scale(0.8)';
    setTimeout(() => {
        card.style.display = 'none';
    }, CONFIG.animationDuration);
}

/**
 * Checks if price falls within specified range
 * @param {number} price - The price to check
 * @param {string} range - The range string (e.g., "0-100000")
 * @returns {boolean} - True if price is in range
 */
function checkPriceRange(price, range) {
    switch(range) {
        case '0-100000':
            return price <= 100000;
        case '100000-250000':
            return price > 100000 && price <= 250000;
        case '250000-500000':
            return price > 250000 && price <= 500000;
        case '500000-1000000':
            return price > 500000;
        default:
            return true;
    }
}

/**
 * Resets all filters to their default state
 */
function resetAllFilters() {
    console.log('Resetting all filters');
    
    const categoryFilter = document.getElementById('category-filter');
    const priceFilter = document.getElementById('price-filter');
    const locationFilter = document.getElementById('location-filter');
    const searchInput = document.getElementById('search-input');
    
    if (categoryFilter) categoryFilter.value = 'all';
    if (priceFilter) priceFilter.value = 'all';
    if (locationFilter) locationFilter.value = 'all';
    if (searchInput) searchInput.value = '';
    
    // Remove search highlights
    document.querySelectorAll('.search-highlight').forEach(el => {
        el.classList.remove('search-highlight');
    });
    
    // Hide no results message
    const noResultsMessage = document.getElementById('no-results');
    if (noResultsMessage) {
        noResultsMessage.style.display = 'none';
    }
    
    filterVehicles();
    showToast('All filters reset successfully', 'success');
}

/**
 * Initializes vehicle count display
 */
function initializeVehicleCount() {
    const vehicleCards = document.querySelectorAll('.vehicle-card');
    if (vehicleCards.length > 0) {
        updateVehicleCount(vehicleCards.length, vehicleCards.length);
    }
}

/**
 * Updates the vehicle count display
 * @param {number} visibleCount - Number of visible vehicles
 * @param {number} totalCount - Total number of vehicles
 */
function updateVehicleCount(visibleCount, totalCount) {
    const visibleCountElement = document.getElementById('visible-count');
    const totalCountElement = document.getElementById('total-count');
    
    if (visibleCountElement) visibleCountElement.textContent = visibleCount;
    if (totalCountElement) totalCountElement.textContent = totalCount;
    
    // Update the count text color based on results
    const vehicleCountElement = document.getElementById('vehicle-count');
    if (vehicleCountElement) {
        if (visibleCount === 0) {
            vehicleCountElement.style.color = '#e63946'; // Red for no results
        } else {
            vehicleCountElement.style.color = ''; // Default color
        }
    }
}

// ===== FORM HANDLING AND VALIDATION =====
/**
 * Initializes all forms on the page with validation and submission handlers
 */
function initializeForms() {
    console.log('Initializing form functionality...');
    
    // Initialize specific forms with their handlers
    const enquiryForm = document.getElementById('enquiry-form');
    if (enquiryForm) {
        enquiryForm.addEventListener('submit', handleEnquirySubmit);
        console.log('Enquiry form initialized');
    }
    
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactSubmit);
        console.log('Contact form initialized');
    }
    
    const financeForm = document.getElementById('finance-calculator');
    if (financeForm) {
        financeForm.addEventListener('submit', handleFinanceApplication);
        console.log('Finance calculator form initialized');
    }
    
    // Initialize real-time form validation
    initializeRealTimeValidation();
}

/**
 * Handles enquiry form submission with validation and AJAX simulation
 * @param {Event} e - Form submission event
 */
function handleEnquirySubmit(e) {
    e.preventDefault();
    console.log('Processing enquiry form submission...');
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    
    // Validate form before submission
    if (!validateForm(form)) {
        showToast('Please correct the errors in the form before submitting.', 'error');
        return;
    }
    
    // Show loading state
    setButtonLoadingState(submitBtn, 'Processing Enquiry...');
    
    // Simulate AJAX form submission
    simulateFormSubmission(form, submitBtn, originalText, 'enquiry')
        .then(() => {
            // Generate specific response based on enquiry type
            const enquiryType = new FormData(form).get('enquiry-type');
            const responseMessage = generateEnquiryResponse(enquiryType, form);
            showToast(responseMessage, 'success');
            form.reset();
        })
        .catch(error => {
            console.error('Enquiry submission error:', error);
            showToast('There was an error submitting your enquiry. Please try again.', 'error');
        })
        .finally(() => {
            resetButtonState(submitBtn, originalText);
        });
}

/**
 * Handles contact form submission
 * @param {Event} e - Form submission event
 */
function handleContactSubmit(e) {
    e.preventDefault();
    console.log('Processing contact form submission...');
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    
    if (!validateForm(form)) {
        showToast('Please correct the errors in the form before submitting.', 'error');
        return;
    }
    
    setButtonLoadingState(submitBtn, 'Sending Message...');
    
    simulateFormSubmission(form, submitBtn, originalText, 'contact')
        .then(() => {
            showToast('Your message has been sent successfully! We will respond within 24 hours.', 'success');
            form.reset();
        })
        .catch(error => {
            console.error('Contact submission error:', error);
            showToast('There was an error sending your message. Please try again.', 'error');
        })
        .finally(() => {
            resetButtonState(submitBtn, originalText);
        });
}

/**
 * Handles finance application form submission
 * @param {Event} e - Form submission event
 */
function handleFinanceApplication(e) {
    e.preventDefault();
    console.log('Processing finance application...');
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    
    if (!validateForm(form)) {
        showToast('Please correct the errors in the form before submitting.', 'error');
        return;
    }
    
    setButtonLoadingState(submitBtn, 'Processing Application...');
    
    simulateFormSubmission(form, submitBtn, originalText, 'finance')
        .then(() => {
            showToast('Finance application submitted successfully! We will contact you within 24 hours with approval status.', 'success');
            form.reset();
            calculatePayment(); // Recalculate after reset
        })
        .catch(error => {
            console.error('Finance application error:', error);
            showToast('There was an error submitting your application. Please try again.', 'error');
        })
        .finally(() => {
            resetButtonState(submitBtn, originalText);
        });
}

// ... (Rest of the JavaScript code remains the same as previous version)
// [Include all the other functions from the previous JavaScript code here]
// Form validation, finance calculator, accordions, image gallery, etc.

// ===== UTILITY FUNCTIONS =====
/**
 * Sets a button to loading state
 * @param {HTMLButtonElement} button - The button element
 * @param {string} loadingText - Text to show during loading
 */
function setButtonLoadingState(button, loadingText) {
    button.innerHTML = `<span class="loading" aria-hidden="true"></span>${loadingText}`;
    button.disabled = true;
    button.setAttribute('aria-disabled', 'true');
}

/**
 * Resets a button to its original state
 * @param {HTMLButtonElement} button - The button element
 * @param {string} originalText - Original button text
 */
function resetButtonState(button, originalText) {
    button.textContent = originalText;
    button.disabled = false;
    button.removeAttribute('aria-disabled');
}

/**
 * Generates appropriate response message for enquiry type
 * @param {string} enquiryType - Type of enquiry
 * @param {HTMLFormElement} form - The form element
 * @returns {string} - Response message
 */
function generateEnquiryResponse(enquiryType, form) {
    const formData = new FormData(form);
    const vehicleModel = formData.get('vehicle-model') || 'selected vehicle';
    
    const responses = {
        'vehicle': `Thank you for your enquiry about the ${vehicleModel}. Our team will contact you with availability and pricing within 24 hours.`,
        'availability': `We'll check the availability for ${vehicleModel} and contact you with options within 24 hours.`,
        'finance': `Thank you for your finance enquiry. Our finance department will contact you with personalized options and rates.`,
        'test-drive': `Your test drive request for ${vehicleModel} has been received. We'll contact you to schedule a convenient time.`,
        'trade-in': `We'll provide you with a competitive trade-in valuation for your vehicle. Our team will contact you within 24 hours.`,
        'service': `Thank you for your service enquiry. Our service department will contact you to discuss your maintenance needs.`
    };
    
    return responses[enquiryType] || 'Thank you for your enquiry! We will contact you soon.';
}

/**
 * Formats a number as currency with commas
 * @param {string|number} num - The number to format
 * @returns {string} - Formatted number string
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Formats a number as South African Rand currency
 * @param {string|number} amount - The amount to format
 * @returns {string} - Formatted currency string
 */
function formatCurrency(amount) {
    return formatNumber(amount);
}

/**
 * Initializes current year in footer for copyright
 */
function initializeCurrentYear() {
    const currentYearElements = document.querySelectorAll('#current-year');
    currentYearElements.forEach(element => {
        element.textContent = new Date().getFullYear();
    });
}

// ===== TOAST NOTIFICATION SYSTEM =====
/**
 * Shows a toast notification to the user
 * @param {string} message - The message to display
 * @param {string} type - The type of toast (success, error, etc.)
 */
function showToast(message, type = 'success') {
    console.log(`Toast [${type}]: ${message}`);
    
    // Remove existing toasts
    const existingToasts = document.querySelectorAll('.toast');
    existingToasts.forEach(toast => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    });
    
    // Create new toast
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'polite');
    
    document.body.appendChild(toast);
    
    // Show toast with animation
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    // Hide toast after duration
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, CONFIG.toastDuration);
}

console.log('NYT Vehicle Dealers - Enhanced JavaScript loaded successfully!');